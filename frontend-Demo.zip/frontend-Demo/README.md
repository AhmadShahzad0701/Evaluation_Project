# Quiz Evaluation Frontend Demo

A modern Next.js TypeScript frontend for the Quiz Evaluation System.

## Project Structure

```
frontend-demo/
├── app/                    # Next.js App Router
│   ├── layout.tsx          # Root layout
│   ├── page.tsx            # Landing page with evaluation form
│   └── result/
│       └── page.tsx        # Results page
├── components/             # React components
│   ├── forms/
│   │   └── EvaluationForm.tsx
│   └── ui/
│       ├── Button.tsx
│       ├── Input.tsx
│       └── Loader.tsx
├── services/               # API services
│   └── evaluation.service.ts
├── types/                  # TypeScript types
│   └── evaluation.ts
├── styles/                 # Global styles
│   └── globals.css
├── public/                 # Static assets
├── package.json
├── tsconfig.json
├── next.config.js
├── tailwind.config.js
├── postcss.config.js
└── .env.local
```

## Setup Instructions

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Environment Configuration**
   Edit `.env.local` to set your API base URL:
   ```
   NEXT_PUBLIC_API_BASE_URL=http://localhost:5000
   ```

3. **Start Development Server**
   ```bash
   npm run dev
   ```

   The application will be available at `http://localhost:3000`

4. **Build for Production**
   ```bash
   npm run build
   npm start
   ```

## Features

- **Evaluation Form**: Submit quiz answers and reference answers for evaluation
- **Results Page**: Display detailed evaluation metrics including:
  - Mean Absolute Error (MAE)
  - Root Mean Squared Error (RMSE)
  - Correlation coefficient
  - Accuracy and F1 Score
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Type-Safe**: Full TypeScript support for better development experience

## API Integration

The frontend communicates with the backend API at the configured `NEXT_PUBLIC_API_BASE_URL`.

### Endpoints Used

- `POST /api/evaluate` - Submit evaluation request
- `GET /api/history` - Get evaluation history
- `GET /api/evaluation/:quizId/:studentId` - Get specific evaluation details

## Technologies Used

- **Next.js 14** - React framework with App Router
- **TypeScript** - Type-safe JavaScript
- **Tailwind CSS** - Utility-first CSS framework
- **Axios** - HTTP client for API calls

## Component Documentation

### EvaluationForm
Handles quiz evaluation form submission with validation.

**Props**: None (uses Next.js hooks internally)

### Button
Reusable button component with variants and sizes.

**Props**:
- `variant`: 'primary' | 'secondary' | 'danger'
- `size`: 'sm' | 'md' | 'lg'
- `fullWidth`: boolean
- `isLoading`: boolean

### Input
Reusable text input component with label and error support.

**Props**:
- `label`: string
- `error`: string
- `helperText`: string
- `fullWidth`: boolean

### Loader
Loading spinner component.

**Props**:
- `size`: 'sm' | 'md' | 'lg'
- `message`: string
- `fullScreen`: boolean

## Development

- Use `npm run dev` for development with hot reload
- Use `npm run lint` to check code quality
- Follow Next.js best practices for routing and component organization

## Notes

- Environment variables must be prefixed with `NEXT_PUBLIC_` to be accessible in the browser
- The API base URL should point to your backend evaluation service
- Ensure CORS is properly configured on the backend to accept requests from the frontend
