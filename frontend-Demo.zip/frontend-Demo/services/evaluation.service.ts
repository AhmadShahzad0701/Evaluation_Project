import axios, { AxiosInstance } from 'axios';
import { EvaluationRequest, EvaluationResponse } from '@/types/evaluation';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:5000';

class EvaluationService {
  private axiosInstance: AxiosInstance;

  constructor() {
    this.axiosInstance = axios.create({
      baseURL: API_BASE_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add response interceptor for error handling
    this.axiosInstance.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response) {
          // Server responded with error status
          throw new Error(
            error.response.data.message ||
              error.response.data.error ||
              'Server error occurred'
          );
        } else if (error.request) {
          // Request was made but no response
          throw new Error('No response from server. Please check your connection.');
        } else {
          // Error in request setup
          throw new Error(error.message || 'An error occurred');
        }
      }
    );
  }

  async submitEvaluation(data: EvaluationRequest): Promise<EvaluationResponse> {
    try {
      const response = await this.axiosInstance.post<EvaluationResponse>(
        '/api/evaluate',
        {
          student_name: data.studentName,
          student_id: data.studentId,
          quiz_id: data.quizId,
          student_answer: data.studentAnswer,
          reference_answer: data.referenceAnswer,
        }
      );

      return response.data;
    } catch (error) {
      console.error('Evaluation submission error:', error);
      throw error;
    }
  }

  async getEvaluationHistory(): Promise<EvaluationResponse[]> {
    try {
      const response = await this.axiosInstance.get<EvaluationResponse[]>(
        '/api/history'
      );

      return response.data;
    } catch (error) {
      console.error('Failed to fetch history:', error);
      throw error;
    }
  }

  async getEvaluationDetails(
    quizId: string,
    studentId: string
  ): Promise<EvaluationResponse> {
    try {
      const response = await this.axiosInstance.get<EvaluationResponse>(
        `/api/evaluation/${quizId}/${studentId}`
      );

      return response.data;
    } catch (error) {
      console.error('Failed to fetch evaluation details:', error);
      throw error;
    }
  }
}

const evaluationService = new EvaluationService();

export const submitEvaluation = (data: EvaluationRequest) =>
  evaluationService.submitEvaluation(data);

export const getEvaluationHistory = () =>
  evaluationService.getEvaluationHistory();

export const getEvaluationDetails = (quizId: string, studentId: string) =>
  evaluationService.getEvaluationDetails(quizId, studentId);
