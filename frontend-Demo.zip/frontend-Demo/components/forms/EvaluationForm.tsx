"use client";

import { FormEvent, useEffect, useState } from "react";
import Button from "@/components/ui/Button";
import Input from "@/components/ui/Input";
import Loader from "@/components/ui/Loader";
import { submitEvaluation } from "@/services/evaluation.service";
import { Rubric } from "../../types";

interface EvaluationRequest {
  studentId: string;
  quizId: string;
  studentName: string;
  studentAnswer: string;
  referenceAnswer: string;
  rubric: Rubric;
  question: string;
  maxScore: number;
  markingScheme: {
    strictness_level: "low" | "medium" | "high";
    criteriaFlags: Record<string, boolean>;
  };
}

interface CustomFormData extends EvaluationRequest {}

const MARKING_FLAGS = [
  "conceptual_understanding",
  "logical_correctness",
  "completeness",
  "attempt_marks",
  "grammar_spelling",
] as const;

const EvaluationForm = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState<CustomFormData>({
    studentId: "",
    quizId: "",
    studentName: "",
    studentAnswer: "",
    referenceAnswer: "",
    question: "",
    maxScore: 10,
    rubric: {
      criteria: [],
    },
    markingScheme: {
      strictness_level: "medium",
      criteriaFlags: {
        conceptual_understanding: true,
        logical_correctness: true,
        completeness: true,
        attempt_marks: false,
        grammar_spelling: false,
      },
    },
  });

  useEffect(() => {
    if (typeof window === "undefined") return;

    const probe = document.createElement("div");
    probe.id = "tw-probe-form";
    probe.className = "bg-blue-500 text-white px-4 py-2";
    document.body.appendChild(probe);

    const styles = window.getComputedStyle(probe);
    const bgColor = styles.backgroundColor;
    const color = styles.color;
    const fontWeight = styles.fontWeight;

    // #region agent log
    fetch("/api/tailwind-probe", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        bgColor,
        color,
        fontWeight,
        runId: "initial",
        hypothesisId: "H1",
      }),
    }).catch(() => {});
    // #endregion

    document.body.removeChild(probe);
  }, []);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setError(null);
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      if (
        !formData.studentName ||
        !formData.studentAnswer ||
        !formData.referenceAnswer
      ) {
        throw new Error("All required fields must be filled.");
      }

      await submitEvaluation(formData);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Evaluation failed";
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRubricChange = (
    index: number,
    field: string,
    value: string | number,
  ) => {
    setFormData((prev) => {
      const updatedCriteria = [...prev.rubric.criteria];
      updatedCriteria[index] = {
        ...updatedCriteria[index],
        [field]: value,
      };

      return {
        ...prev,
        rubric: {
          ...prev.rubric,
          criteria: updatedCriteria,
        },
      };
    });
  };

  const addRubricCriterion = () => {
    setFormData((prev) => ({
      ...prev,
      rubric: {
        ...prev.rubric,
        criteria: [
          ...prev.rubric.criteria,
          { name: "", description: "", weight: 0 },
        ],
      },
    }));
  };

  if (isLoading) {
    return <Loader message="Processing evaluation..." />;
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label="Question"
        name="question"
        value={formData.question}
        onChange={handleInputChange}
        required
      />

      <Input
        label="Max Score"
        name="maxScore"
        type="number"
        value={formData.maxScore}
        onChange={handleInputChange}
        required
      />

      {/* MARKING SCHEME */}
      <div>
        <label className="block text-sm font-medium mb-2">
          Marking Criteria
        </label>

        {MARKING_FLAGS.map((flag) => (
          <div key={flag} className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={formData.markingScheme.criteriaFlags[flag]}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  markingScheme: {
                    ...prev.markingScheme,
                    criteriaFlags: {
                      ...prev.markingScheme.criteriaFlags,
                      [flag]: e.target.checked,
                    },
                  },
                }))
              }
            />
            <span className="text-sm">
              {flag.replace(/_/g, " ")}
            </span>
          </div>
        ))}

        <div className="mt-4">
          <label className="block text-sm font-medium mb-2">
            Strictness Level
          </label>
          <select
            className="border rounded px-3 py-2"
            value={formData.markingScheme.strictness_level}
            onChange={(e) =>
              setFormData((prev) => ({
                ...prev,
                markingScheme: {
                  ...prev.markingScheme,
                  strictness_level: e.target.value as
                    | "low"
                    | "medium"
                    | "high",
                },
              }))
            }
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
      </div>

      {/* RUBRIC */}
      <div>
        <label className="block text-sm font-medium mb-2">
          Rubric Criteria
        </label>

        {formData.rubric.criteria.map((criterion, index) => (
          <div key={index} className="border p-4 rounded mb-4 space-y-2">
            <Input
              label="Description"
              value={criterion.description}
              onChange={(e) =>
                handleRubricChange(index, "description", e.target.value)
              }
              required
            />
            <Input
              label="Weight"
              type="number"
              value={criterion.weight}
              onChange={(e) =>
                handleRubricChange(
                  index,
                  "weight",
                  Number(e.target.value),
                )
              }
              required
            />
          </div>
        ))}

        <Button type="button" onClick={addRubricCriterion} size="sm">
          Add Criterion
        </Button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 p-3 rounded">
          <p className="text-red-700">{error}</p>
        </div>
      )}

      <Button type="submit" fullWidth size="lg">
        Submit Evaluation
      </Button>
    </form>
  );
};

export default EvaluationForm;
