import React from 'react';

interface Rubric {
  criteria: Criterion[];
}

interface Criterion {
  name: string;
  description: string;
  weight: number;
}

const RubricDisplay = ({ rubric }: { rubric: Rubric }) => {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Rubric
      </label>
      <ul className="space-y-4">
        {rubric.criteria.map((criterion, index) => (
          <li key={index} className="border p-4 rounded-lg">
            <p className="font-semibold">{criterion.name} ({criterion.weight}%)</p>
            <p className="text-sm text-gray-600">{criterion.description}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RubricDisplay;