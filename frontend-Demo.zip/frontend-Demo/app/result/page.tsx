'use client';

import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import Button from '@/components/ui/Button';
import { Suspense } from 'react';

interface EvaluationResult {
  mae: number;
  rmse: number;
  correlation: number;
  accuracy: number;
  f1_score: number;
  system_response: string;
  timestamp: string;
}

function ResultContent() {
  const searchParams = useSearchParams();
  if (!searchParams) {
    return <div>Error: Search parameters are missing.</div>;
  }

  const result = searchParams.get('result');

  let evaluationResult: EvaluationResult | null = null;

  if (result) {
    try {
      evaluationResult = JSON.parse(decodeURIComponent(result));
    } catch (error) {
      console.error('Failed to parse result:', error);
    }
  }

  if (!evaluationResult) {
    return (
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">
          No Results Found
        </h1>
        <p className="text-gray-600 mb-6">
          Please submit an evaluation form to see results.
        </p>
        <Link href="/">
          <Button>Back to Evaluation Form</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">
          Evaluation Results
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-blue-50 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Performance Metrics
            </h2>
            <div className="space-y-3">
              <div>
                <p className="text-sm font-medium text-gray-600">
                  Mean Absolute Error (MAE)
                </p>
                <p className="text-2xl font-bold text-blue-600">
                  {evaluationResult.mae.toFixed(4)}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">
                  Root Mean Squared Error (RMSE)
                </p>
                <p className="text-2xl font-bold text-blue-600">
                  {evaluationResult.rmse.toFixed(4)}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">
                  Correlation
                </p>
                <p className="text-2xl font-bold text-blue-600">
                  {evaluationResult.correlation.toFixed(4)}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-green-50 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Accuracy Metrics
            </h2>
            <div className="space-y-3">
              <div>
                <p className="text-sm font-medium text-gray-600">
                  Accuracy
                </p>
                <p className="text-2xl font-bold text-green-600">
                  {(evaluationResult.accuracy * 100).toFixed(2)}%
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">
                  F1 Score
                </p>
                <p className="text-2xl font-bold text-green-600">
                  {evaluationResult.f1_score.toFixed(4)}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-600">
                  Timestamp
                </p>
                <p className="text-sm text-gray-700">
                  {new Date(evaluationResult.timestamp).toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            System Response
          </h2>
          <p className="text-gray-700 whitespace-pre-wrap">
            {evaluationResult.system_response}
          </p>
        </div>

        <div className="flex gap-4">
          <Link href="/">
            <Button>New Evaluation</Button>
          </Link>
          <button
            onClick={() => window.print()}
            className="px-6 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition"
          >
            Print Results
          </button>
        </div>
      </div>
    </div>
  );
}

export default function ResultPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ResultContent />
    </Suspense>
  );
}
