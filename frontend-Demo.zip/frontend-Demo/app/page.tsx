"use client";

import React, { useEffect, useState } from "react";

const RubricDefinition = () => {
  const [criteria, setCriteria] = useState([
    { name: "", description: "", weight: 0 },
  ]);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const probe = document.createElement("div");
    probe.id = "tw-probe";
    probe.className = "bg-blue-500 text-white px-4 py-2";
    document.body.appendChild(probe);

    const styles = window.getComputedStyle(probe);
    const bgColor = styles.backgroundColor;
    const color = styles.color;
    const fontWeight = styles.fontWeight;

    // #region agent log
    fetch("/api/tailwind-probe", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        bgColor,
        color,
        fontWeight,
        runId: "initial",
        hypothesisId: "H1",
      }),
    }).catch(() => {});
    // #endregion

    document.body.removeChild(probe);
  }, []);

  const addCriterion = () => {
    setCriteria([...criteria, { name: "", description: "", weight: 0 }]);
  };

  const removeCriterion = (index: number) => {
    const updatedCriteria = criteria.filter((_, i) => i !== index);
    setCriteria(updatedCriteria);
  };

  const updateCriterion = (index: number, field: string, value: string | number) => {
    const updatedCriteria = [...criteria];
    updatedCriteria[index] = { ...updatedCriteria[index], [field]: value };
    setCriteria(updatedCriteria);
  };

  const totalWeight = criteria.reduce((sum, criterion) => sum + (criterion.weight || 0), 0);

  return (
    <div className="card">
      <div className="card-header">
        <h2 className="card-title">Define Rubric</h2>
        <p className="card-description">Specify evaluation criteria and their respective weights</p>
      </div>

      <div id="rubricCriteriaList">
        {criteria.map((criterion, index) => (
          <div key={index} className="rubric-criterion space-y-4 border p-4 rounded-lg mb-4">
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Criterion Name</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g., Conceptual Understanding"
                  value={criterion.name}
                  onChange={(e) => updateCriterion(index, "name", e.target.value)}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Weight (%)</label>
                <input
                  type="number"
                  className="form-input"
                  min="0"
                  max="100"
                  placeholder="e.g., 50"
                  value={criterion.weight}
                  onChange={(e) => updateCriterion(index, "weight", parseFloat(e.target.value))}
                />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea
                className="form-textarea"
                placeholder="Describe the criterion..."
                value={criterion.description}
                onChange={(e) => updateCriterion(index, "description", e.target.value)}
              ></textarea>
            </div>
            <button
              className="button button-danger"
              onClick={() => removeCriterion(index)}
            >
              Remove Criterion
            </button>
          </div>
        ))}
      </div>

      <button className="button button-secondary" onClick={addCriterion}>
        ➕ Add Criterion
      </button>

      <div className="form-group mt-4">
        <label className="form-label">Total Weight</label>
        <div className="progress-bar">
          <div
            className="progress-fill"
            style={{ width: `${totalWeight}%`, backgroundColor: totalWeight > 100 ? "red" : "green" }}
          ></div>
        </div>
        <p>Total: {totalWeight}%</p>
      </div>
    </div>
  );
};

export default RubricDefinition;
