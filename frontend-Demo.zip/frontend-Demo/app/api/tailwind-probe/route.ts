import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

const LOG_PATH = path.join(process.cwd(), ".cursor", "debug.log");

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      bgColor,
      color,
      fontWeight,
      runId = "initial",
      hypothesisId = "H1",
    } = body ?? {};

    const logEntry = {
      id: `log_${Date.now()}_tailwind_probe_api`,
      timestamp: Date.now(),
      location: "app/api/tailwind-probe/route.ts:POST",
      message: "Tailwind probe data from client",
      data: { bgColor, color, fontWeight },
      runId,
      hypothesisId,
    };

    // #region agent log
    fetch(
      "http://127.0.0.1:7242/ingest/c293fe80-3bd7-4735-8c05-0333d786945b",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(logEntry),
      },
    ).catch(() => {});

    fs.appendFile(LOG_PATH, JSON.stringify(logEntry) + "\n", () => {});
    // #endregion

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false }, { status: 500 });
  }
}

