export interface Criterion {
  name: string;
  weight: number;
  description: string;
}

export interface Rubric {
  criteria: Criterion[];
}