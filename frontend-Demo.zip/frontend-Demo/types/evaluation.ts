export interface EvaluationRequest {
  studentName: string;
  studentId: string;
  quizId: string;
  studentAnswer: string;
  referenceAnswer: string;
}

export interface EvaluationResponse {
  mae: number;
  rmse: number;
  correlation: number;
  accuracy: number;
  f1_score: number;
  system_response: string;
  timestamp: string;
}

export interface ApiError {
  error: string;
  message?: string;
  status?: number;
}
